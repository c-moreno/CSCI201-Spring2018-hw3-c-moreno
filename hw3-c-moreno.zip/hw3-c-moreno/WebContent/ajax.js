function validate(pageToForward) {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "ValidateServlet?q=" + document.myform.q.value + "&searchType=" + 
			document.myform.searchType.value + "&pageToForward=" + pageToForward, false);
	xhttp.send();
	if(xhttp.responseText.trim().length > 0) { 
		return false;
	}
	return true;
}

function validateLogin() {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "ValidateLoginServlet?username=" + document.myform.username.value + "&password=" + 
			document.myform.password.value, false);
	xhttp.send();
	response = xhttp.responseText.trim();
	
	//set all errors blank to start
	document.getElementById("usernameErr").innerHTML = "";
	document.getElementById("passwordErr").innerHTML = "";
	document.getElementById("loginErr").innerHTML = "";
	
	if(response.charAt(0) == 1 || response.charAt(1) == 1|| response.charAt(2) == 1) {
		//0th index is username not filled in, 1 is password, 2 is imageURL
		if(xhttp.responseText.charAt(0) == 1) {
			document.getElementById("usernameErr").innerHTML = "Entry cannot be empty";
		}
		if(xhttp.responseText.charAt(1) == 1) {
			document.getElementById("passwordErr").innerHTML = "Entry cannot be empty";
		}
		if(xhttp.responseText.charAt(2) == 1) {
			document.getElementById("loginErr").innerHTML = "Login Failed";
		}
		return false;
	}
	return true;
}

function toggle(which, other) {
	document.getElementById(which).style.cursor="auto";
	document.getElementById(which).style.backgroundColor="rgb(83, 132, 169)";
	document.getElementById(other).style.cursor="pointer";
	document.getElementById(other).style.backgroundColor="rgb(53, 84, 124)";
	
	document.getElementById(which + "List").style.display="block";
	document.getElementById(other + "List").style.display="none";
}

function toggleBooks(which, other) {
	document.getElementById(which).style.cursor="auto";
	document.getElementById(which).style.backgroundColor="rgb(83, 132, 169)";
	document.getElementById(other).style.cursor="pointer";
	document.getElementById(other).style.backgroundColor="rgb(53, 84, 124)";
	
	document.getElementById(which + "Books").style.display="block";
	document.getElementById(other + "Books").style.display="none";
}

function addToLibrary(name, type) {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "AddReadFav?bookName=" + name + "&type=" + type, true);
	xhttp.send();
	
	response = xhttp.responseText.trim();
}

function validateSignUp() {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "ValidateSignUpServlet?username=" + document.myform.username.value + "&password=" + 
			document.myform.password.value + "&imageURL=" + document.myform.imageURL.value, false);
	xhttp.send();
	response = xhttp.responseText.trim();
	
	//set all errors blank to start
	document.getElementById("usernameErr").innerHTML = "";
	document.getElementById("passwordErr").innerHTML = "";
	document.getElementById("imageURLErr").innerHTML = "";
	
	if(response.charAt(0) == 1 || response.charAt(1) == 1|| response.charAt(2) == 1 || response.charAt(3) == 1) {
		//0th index is username not filled in, 1 is password, 2 is imageURL, 3 is username taken
		if(xhttp.responseText.charAt(0) == 1) {
			document.getElementById("usernameErr").innerHTML = "Entry cannot be empty";
		}
		if(xhttp.responseText.charAt(1) == 1) {
			document.getElementById("passwordErr").innerHTML = "Entry cannot be empty";
		}
		if(xhttp.responseText.charAt(2) == 1) {
			document.getElementById("imageURLErr").innerHTML = "Entry cannot be empty";
		}
		if(xhttp.responseText.charAt(3) == 1) {
			document.getElementById("usernameErr").innerHTML = "Username Taken";
		}
		return false;
	}
	return true;
}