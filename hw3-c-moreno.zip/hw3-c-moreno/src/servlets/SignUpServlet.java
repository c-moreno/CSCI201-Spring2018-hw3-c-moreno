package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import userFiles.User;
import userFiles.UserList;
import userFiles.UserParser;

/**
 * Servlet implementation class ValidateServlet
 */
@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String imageURL = request.getParameter("imageURL");
		
		//save user
		UserList userlist = (UserList) request.getSession().getAttribute("userlist");
		User curUser = new User(username, password, imageURL);
		userlist.add(curUser);
		UserParser parser = new UserParser();
		//String file = "/Users/Kaden/Documents/College/Sophomore Year S2/CSCI 201/hw3-c-moreno/WebContent/database.json";
		String file = getServletContext().getRealPath("/Sample.json");
		parser.toJSON(userlist, file);
		request.getSession().setAttribute("userlist", userlist);
		
		//set user
		request.getSession().setAttribute("user", curUser);
	
		//send to resultspage through SearchServlet
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/SearchServlet?q=&type=&justIn=true");
		dispatch.forward(request,  response);
	}
}


