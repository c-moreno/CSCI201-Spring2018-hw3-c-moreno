package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import userFiles.UserList;
import userFiles.UserParser;
import userFiles.User;

/**
 * Servlet implementation class ValidateServlet
 */
@WebServlet("/ValidateSignUpServlet")
public class ValidateSignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String imageURL = request.getParameter("imageURL");
		
		PrintWriter out = response.getWriter();
		StringBuilder responseStringBuilder = new StringBuilder("00000");
		//0th index is username not filled in, 1 is password, 2 is imageURL, 3 is username taken
		boolean failed = false;
		boolean nameInput = true;
		
		if (username == null || username == "") {
			responseStringBuilder.setCharAt(0, '1');
			nameInput = false;
		}
		
		if(password == null || password == "") {
			responseStringBuilder.setCharAt(1, '1');
		}
		
		if(imageURL == null || imageURL == "") {
			responseStringBuilder.setCharAt(2, '1');
		}
		
		if(nameInput == true) {
			HttpSession session = request.getSession();
			UserList userlist = (UserList) session.getAttribute("userlist");
			if(userlist.nameTaken(username)) {
				responseStringBuilder.setCharAt(3, '1');
			}
		}
		
		out.println(responseStringBuilder.toString());
	    	out.flush();
	    	out.close();
	}
}


