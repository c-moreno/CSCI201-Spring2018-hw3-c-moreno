package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

import bookFiles.BookList;
import userFiles.UserList;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String just = request.getParameter("justIn");
		Boolean justIn = false;
		if(just != null && just.equals("true")) {
			justIn = true;
		}
		
		if(justIn != null && justIn == true) {
			request.setAttribute("justIn", true);
			justIn = true;
		} else {
			request.setAttribute("justIn", false);
		}
		
		//do searches as necessary
		Boolean searchBooks = (Boolean)request.getSession().getAttribute("searchBooks");
		if(searchBooks == null) {
			searchBooks = true;
			request.getSession().setAttribute("searchBooks", searchBooks);
		}
		
		String search = request.getParameter("q");
		if(search == null ) {
			search = "";
		}
		if(searchBooks) {
			String type = request.getParameter("searchType");
			BookList books = new BookList();
			if(search != null && search.length() != 0) {
				books = search(search, type);
			}
			request.setAttribute("books", books);
		} else {
			UserList users = (UserList)request.getSession().getAttribute("userlist");
			UserList results = users.search(search);
			if(justIn) {
				results = new UserList();
			}
			request.setAttribute("users", results);
		}
		
		//reset search values to null
		request.setAttribute("search", null);
		request.setAttribute("type", null);
		
		//send to resultspage
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/resultspage.jsp");
		dispatch.forward(request,  response);
	}

	private BookList search(String search, String type) {
		String searchPlus = search.replace(' ', '+');
		String url = "https://www.googleapis.com/books/v1/volumes?q=type" + ":" + searchPlus + "&maxResults=12"; //+ "&key=AIzaSyCqNvWSPrTyTvAPuOgvq_wRu5gIxbmRsjg"
		
		//use google books api
		StringBuilder response;
		try {
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) "
					+ "AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.0 Safari/532.5"); //user agent doesn't matter
			int responseCode = con.getResponseCode();
			if(responseCode != 200) {
				return null;
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			response = new StringBuilder();
	
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine).append("\n");
			}
			in.close();
		} catch (MalformedURLException mue) {
			System.out.println(mue.getMessage());
			return null;
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
			return null;
		} 	
	
		String gsonString = response.toString();
		
		//parse gsonString
		BookList bookResults = null;
		Gson gson = new Gson();
		try {
			bookResults = gson.fromJson(gsonString, BookList.class);
		} catch(JsonParseException jpe) {
			return null;
		} 
		return bookResults;
	}
}
