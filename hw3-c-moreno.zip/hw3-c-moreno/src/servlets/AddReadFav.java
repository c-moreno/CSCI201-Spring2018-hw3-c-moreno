package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import userFiles.User;
import userFiles.UserList;
import userFiles.UserParser;

/**
 * Servlet implementation class AddReadFav
 */
@WebServlet("/AddReadFav")
public class AddReadFav extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User curUser = (User) request.getSession().getAttribute("user");
		UserList userlist = (UserList) request.getSession().getAttribute("userlist");
		String type = (String) request.getParameter("type");
		String bookName = (String) request.getParameter("bookName");
		
		userlist.get(curUser.getName()).addToLibrary(bookName, type);
		request.getSession().setAttribute("userlist", userlist);
		
		UserParser parse = new UserParser();
		//String file = "/Users/Kaden/Documents/College/Sophomore Year S2/CSCI 201/hw3-c-moreno/WebContent/database.json";
		String file = getServletContext().getRealPath("/Sample.json");
		parse.toJSON(userlist, file);
		
		
		PrintWriter out = response.getWriter();
	 	out.flush();
	 	out.close();
	}

}
