package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

import bookFiles.Book;
import bookFiles.BookList;
import userFiles.User;
import userFiles.UserList;

/**
 * Servlet implementation class UserProfile
 */
@WebServlet("/UserProfile")
public class UserProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		UserList userlist = (UserList) request.getSession().getAttribute("userlist");
		User lookUpUser = userlist.get(name);
		
		request.getSession().setAttribute("searchBooks", false);
		
		//set lookUpUser
		request.setAttribute("lookUpUser", lookUpUser);
		
		//find favorite book list
		ArrayList<String> bookNames = lookUpUser.getFavoriteBooks();
		BookList books = new BookList();
		for(int i = 0; i < bookNames.size(); i++) {
			books.add(getBook(bookNames.get(i)));
		}
		request.setAttribute("favoriteBooks", books);
		
		//find read book list
		ArrayList<String> readBookNames = lookUpUser.getReadBooks();
		BookList readBooks = new BookList();
		for(int i = 0; i < readBookNames.size(); i++) {
			readBooks.add(getBook(readBookNames.get(i)));
		}
		request.setAttribute("readBooks", readBooks);
		
		if(request.getAttribute("following") == null) {
			request.setAttribute("following", true);
		}
	
		//send to userinfo
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/userinfo.jsp");
		dispatch.forward(request,  response);
	}
	
	private Book getBook(String search) {
		String searchPlus = search.replace(' ', '+');
		
		String url = "https://www.googleapis.com/books/v1/volumes?q=type" + ":" + searchPlus + "&maxResults=1"; //+ "&key=AIzaSyCqNvWSPrTyTvAPuOgvq_wRu5gIxbmRsjg"
		
		//use google books api
		StringBuilder response;
		try {
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) "
					+ "AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.0 Safari/532.5"); //user agent doesn't matter
			int responseCode = con.getResponseCode();
			if(responseCode != 200) {
				return null;
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			response = new StringBuilder();
	
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine).append("\n");
			}
			in.close();
		} catch (MalformedURLException mue) {
			System.out.println(mue.getMessage());
			return null;
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
			return null;
		} 	
	
		String gsonString = response.toString();
		
		//parse gsonString
		BookList bookResults = null;
		Gson gson = new Gson();
		try {
			bookResults = gson.fromJson(gsonString, BookList.class);
		} catch(JsonParseException jpe) {
			return null;
		} 
		
		if(bookResults.getSize() == 0) {
			return new Book();
		} 
		return bookResults.getBook(0);
	}
	
}
