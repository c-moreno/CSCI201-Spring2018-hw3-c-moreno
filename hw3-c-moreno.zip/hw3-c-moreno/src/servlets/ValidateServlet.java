package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidateServlet
 */
@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Boolean searchBooks = (Boolean)request.getSession().getAttribute("searchBooks");
		
		String search = request.getParameter("q");
		String type = request.getParameter("searchType");
		
		PrintWriter out = response.getWriter();
		if (searchBooks && (type == null || type == "")) {
			out.println("<font color=\"red\">Choose a search type.</font>");
		}
		
		if(searchBooks && (search == null || search == "")) {
			out.println("<font color=\"red\">Enter search terms</font>");
		}
		
	    	out.flush();
	    	out.close();
	}
}


