package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import userFiles.User;
import userFiles.UserList;

/**
 * Servlet implementation class ValidateServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		//set user
		UserList userlist = (UserList) request.getSession().getAttribute("userlist");
		User curUser = userlist.login(username, password);
		request.getSession().setAttribute("user", curUser);
	
		//send to resultspage through SearchServlet
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/SearchServlet?q=&type=&justIn=true");
		dispatch.forward(request,  response);
	}
}


