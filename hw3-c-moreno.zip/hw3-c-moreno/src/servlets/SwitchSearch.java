package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bookFiles.BookList;
import userFiles.UserList;

/**
 * Servlet implementation class SwitchSearch
 */
@WebServlet("/SwitchSearch")
public class SwitchSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//set searchBooks
		Boolean searchBooks = (Boolean) request.getSession().getAttribute("searchBooks");
		request.getSession().setAttribute("searchBooks", !searchBooks);
		request.setAttribute("books", new BookList());
		request.setAttribute("users", new UserList());
		
	
		//send to resultspage through SearchServlet
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/SearchServlet?q=&searchType=title&justIn=true");
		dispatch.forward(request,  response);
	}
}


