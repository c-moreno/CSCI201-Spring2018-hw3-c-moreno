package bookFiles;

import java.util.ArrayList;

public class BookList {
	String kind;
	int totalItems; //don't use this for size
	ArrayList<Book> items;
	
	public BookList() {
		items = new ArrayList<Book>();
	}
	
	public int getSize() {
		if(items == null || items.size() == 0) {
			return 0;
		}
		return items.size();
	}
	public Book getBook(int id) {
		return items.get(id);
	}
	
	public void add(Book book) {
		items.add(book);
	}
	
	public void print() {
		for(int i = 0; i < items.size(); i++) {
			System.out.println(items.get(i).getTitle());
		}
	}
}

