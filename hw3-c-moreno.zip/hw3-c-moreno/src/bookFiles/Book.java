package bookFiles;

public class Book {
	String kind;
	String id;
	String etag;
	String selfLink;
	VolumeInfo volumeInfo;
	SaleInfo saleInfo;
	AccessInfo accessInfo;
	SearchInfo searchInfo;

	
	
	
	public String getTitle(){
		return volumeInfo.getTitle();
	}
	public String getAuthor(){
		return volumeInfo.getAuthor();
	}
	public String getLink() {
		return volumeInfo.getLink();
	}
	public String getDescription() {
		return volumeInfo.getDescription();
	}
	public String getPublisher() {
		return volumeInfo.getPublisher();
	}
	public double getAvgRate() {
		return volumeInfo.getAvgRate();
	}
	
	public class SaleInfo {
		String country;
		String saleability;
		Boolean isEbook;
	}
	
	public class AccessInfo {
		String country;
		String viewability;
		Boolean embeddable;
		Boolean publicDomain;
		String textToSpeechPermission;
		EPUB epub;
		PDF pdf;
		String webReaderLink;
		String accessViewStatus;
		Boolean quoteSharingAllowed;
	}
	
	public class SearchInfo {
		String textSnippet;
	}
}


