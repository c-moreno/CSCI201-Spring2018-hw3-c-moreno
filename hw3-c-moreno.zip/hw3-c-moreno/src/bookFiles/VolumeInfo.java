package bookFiles;

import java.util.ArrayList;

public class VolumeInfo {
	String title;
	ArrayList<String> authors;
	String publisher;
	String publishedDate;
	String description;
	ArrayList<IndustryIdentifiers> industryIdentifiers;
	ReadingModes readingModes;
	int pageCount;
	String printType;
	ArrayList<String> categories;
	double averageRating;
	int ratingsCount;
	String maturityRating;
	Boolean allowAnonLogging;
	String contentVersion;
	ImageLinks imageLinks;
	String language;
	String previewLink;
	String infoLink;
	String canonicalVolumeLink;
	
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		if(authors == null || authors.size() == 0 || authors.get(0) == null || (authors.get(0)).length() == 0) {
			return "";
		}
		else if(authors.size() == 1) {
			return authors.get(0);
		}
		else if(authors.size() == 2) {
			return (authors.get(0) + " and " + authors.get(1));
		}
		else{
			StringBuilder authorBuilder = new StringBuilder();
			authorBuilder.append(authors.get(0));
			for(int i = 1; i < authors.size() - 1; i++) {
				authorBuilder.append(", ").append(authors.get(i));
			}
			authorBuilder.append(", and ").append(authors.get(authors.size()-1));
			return authorBuilder.toString();
		}
	}
	public String getLink() {
		if(imageLinks == null) {
			return "";
		}
		return imageLinks.getPic();
	}
	public String getDescription() {
		if(description == null) {
			return "";
		}
		return description;
	}
	public String getPublisher() {
		if(publisher == null) {
			return "";
		}
		return publisher;
	}
	public double getAvgRate() {
		return averageRating;
	}
	
	public class IndustryIdentifiers {
		String type;
		String identifier;
	}
	
	public class ReadingModes {
		Boolean text;
		Boolean image;
	}
	
	public class ImageLinks {
		String smallThumbnail;
		String thumbnail;
		
		String getPic(){
			if(thumbnail == null) {
				return "";
			}
			return thumbnail;
		}
	}
}

