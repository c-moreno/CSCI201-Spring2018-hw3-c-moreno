package bookFiles;

public class EPUB {
	Boolean isAvailable;
}
