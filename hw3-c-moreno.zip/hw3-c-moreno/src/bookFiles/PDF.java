package bookFiles;

public class PDF {
	Boolean isAvailable;
}
