package userFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

public class UserParser {
	public UserParser() {
		
	}
	
	public void toJSON(UserList userlist, String file) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(userlist);
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(file);
			pw = new PrintWriter(fw);
			pw.println(json);
			pw.flush();
		} catch(IOException ioe) {
			System.out.println(ioe.getMessage());
		}
		if(pw != null) {
			pw.close();
		}
		if(fw != null) {
			try {
				fw.close();
			} catch(IOException ioe) {
				System.out.println(ioe.getMessage());
			}
		}
	}
	
	public UserList fromJSON(String file) {
		StringBuilder database;
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String inputLine;
			database = new StringBuilder();
	
			while ((inputLine = in.readLine()) != null) {
				database.append(inputLine).append("\n");
			}
			in.close();
		} catch (IOException ioe) {
			System.out.println("error in fromJSON in UserParser");
			System.out.println(ioe.getMessage());
			return null;
		} 	
		
		
		String gsonString = database.toString();
		UserList userlist = null;
		Gson gson = new Gson();
		try {
			userlist = gson.fromJson(gsonString, UserList.class);
		} catch(JsonParseException jpe) {
			return null;
		}
		return userlist;
	}
}
