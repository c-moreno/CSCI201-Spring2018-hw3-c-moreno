package userFiles;

import java.util.ArrayList;

public class User {
	String username;
	String password;
	String imageURL;
	ArrayList<String> followers;
	private ArrayList<String> following;
	Library library;
	
	public  User(String un, String pw, String iURL) {
		username = un;
		password = pw;
		imageURL = iURL;
		followers = new ArrayList<String>();
		following = new ArrayList<String>();
		library = new Library();
	}
	
	public ArrayList<String> getFollowers() {
		return followers;
	}
	
	public ArrayList<String> getFollowing() {
		return following;
	}
	
	public String getName() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public Boolean beginsWith(String substring) {
		substring = substring.toUpperCase();
		String un = username.toUpperCase();
		
		for(int i = 0; i < substring.length(); i++) {
			if(!(i < un.length() && un.charAt(i) == substring.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	public String getLink() {
		return imageURL;
	}
	
	public void follow(String name) {
		if(following.contains(name)) {
			return;
		}
		else {
			following.add(name);
		}
	}
	
	public void followed(String name) {
		if(followers.contains(name)) {
			return;
		} else {
			followers.add(name);
		}
	}
	
	public void unFollow(String name) {
		following.remove(name);
	}
	
	public void unFollowed(String name) {
		followers.remove(name);
	}
	
	public Boolean isFollowing(String name) {
		return(following.contains(name));
	}
	
	public ArrayList<String> getFavoriteBooks() {
		return library.getFavorites();
	}
	
	public ArrayList<String> getReadBooks() {
		return library.getRead();
	}
	
	public void addToLibrary(String name, String type) {
		library.addToLibrary(name, type);
	}
	
	public class Library {
		ArrayList<String> read;
		ArrayList<String> favorite;
		
		public Library() {
			read = new ArrayList<String>();
			favorite = new ArrayList<String>();
		}
		
		public ArrayList<String> getFavorites() {
			if(favorite == null) {
				return new ArrayList<String>();
			} else {
				return favorite;
			}
		}
		
		public ArrayList<String> getRead() {
			if(read == null) {
				return new ArrayList<String>();
			} else {
				return read;
			}
		}
		
		public void addToLibrary(String name, String type) {
			if(type.equals("read")) {
				if(!read.contains(name)) {
					read.add(name);
				}
			}
			if(type.equals("favorite")) {
				if(!favorite.contains(name)) {
					favorite.add(name);
				}
			}
		}
	}
	
}
