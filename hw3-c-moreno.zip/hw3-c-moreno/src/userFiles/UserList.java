package userFiles;

import java.util.ArrayList;

public class UserList {
	ArrayList<User> users;
	
	public UserList() {
		users = new ArrayList<User>();
	}
	
	public User get(String name) {
		for(int i = 0; i < users.size(); i++) {
			if(users.get(i).getName().equals(name)) {
				return users.get(i);
			}
		}
		return null;
	}
	
	public int getSize() {
		return users.size();
	}
	
	public boolean nameTaken(String username) {
		for(int i = 0; i < users.size(); i++) {
			if(users.get(i).getName().equals(username)) {
				return true;
			}
		}
		return false;
	}
	
	public User login(String username, String password) {
		for(int i = 0; i < users.size(); i++) {
			if(users.get(i).getName().equals(username) && users.get(i).getPassword().equals(password)) {
				return users.get(i);
			}
		}
		return null;
	}
	
	public UserList search(String substring) {
		UserList results = new UserList();
		for(int i = 0; i < users.size(); i++) {
			if(users.get(i).beginsWith(substring)) {
				results.add(users.get(i));
			}
		}
		return results;
	}
	
	public void add(User user) {
		users.add(user);
	}
	
	public String getName(int i) {
		if(i >= users.size()) {
			return "";
		}
		else {
			return users.get(i).getName();
		}
	}

	public String getLink(int i) {
		if(i >= users.size()) {
			return "";
		}
		else {
			return users.get(i).getLink();
		}
	}
	
	public void follow(String curName, String otherName) {
		int cur = find(curName);
		int other = find(otherName);
		if(cur == -1 || other == -1) {
			return;
		}
		users.get(cur).follow(otherName);
		users.get(other).followed(curName);
	}
	
	public void unFollow(String curName, String otherName) {
		int cur = find(curName);
		int other = find(otherName);
		if(cur == -1 || other == -1) {
			return;
		}
		users.get(cur).unFollow(otherName);
		users.get(other).unFollowed(curName);
	}
	
	public Boolean isFollowing(String curName, String otherName) {
		int cur = find(curName);
		int other = find(otherName);
		if(cur == -1 || other == -1) {
			return false;
		}
		return users.get(cur).isFollowing(otherName);
	}
	
	private int find(String name) {
		for(int i = 0; i < users.size(); i++) {
			if(users.get(i).getName().equals(name)) {
				return i;
			}
		}
		return -1;
	}
	
	public void print() {
		for(int i = 0; i < users.size(); i++) {
			System.out.println(users.get(i).getName());
			System.out.println(users.get(i).getPassword());
		}
	}
}
